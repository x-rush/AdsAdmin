--数学函数篇
SELECT CEIL(1.9); --进一取整
SELECT ABS(-12); --取绝对值
SELECT FLOOR(2.9); --舍掉小数部分
SELECT POWER(2,3); --幂运算
SELECT ROUND(3.56789,2); --四舍五入
SELECT PI(); --圆周率
SELECT TRUNCATE(3.56789,3); --截取小点后几位
SELECT RAND();--生成0~1之间的随机数 
SELECT RAND(N); --生成一个固定的0~1之间的随机数
SELECT (CEIL(RAND() * (y-x+1)) + (x-1)); -- 取x-y之间的随机数
SELECT MOD(5,2); --取余数
SELECT SIGN(-12); SELECT SIGN(12); SELECT SIGN(0);  --得到数字符号
------------------------------------------------------------------------------------

-- 测试字符串函数
-- CHAR_LENGTH():得到字符串的字符数
SELECT CHAR_LENGTH('abc');

-- LENGTH():返回字符串的长度
SELECT LENGTH('abc');

-- CONCAT(s1,s2,....):将字符串合并成一个字符串

SELECT CONCAT('a','b','c');
-- 如果字符串中包含NULL，返回拼接结果就是NULL
SELECT CONCAT('a','b','c',null);

-- CONCAT_WS(x,s1,s2,s2....)：以指定分隔符拼接字符串
SELECT CONCAT_WS('-','a','b','c');
-- 如果null在拼接的内容中，则转化成空字符串
SELECT CONCAT_WS('-','a','b','c',null);
-- 如果分隔符为null，拼接的结果为null
SELECT CONCAT_WS(null,'a','b','c');
-- 将字符串转换成大写或者小写 UPPER()| UCASE() LOWER()|LCASE()
SELECT UPPER('hello king'),UCASE('hello imooc'),LOWER('HELLO ADMIN'),LCASE('HELLO EVERYBODY');

-- 字符串的反转REVERSE()
SELECT REVERSE('abc');

-- LEFT()|RIGHT():返回字符串的前几个字符或者后几个字符
SELECT LEFT('hello',2),RIGHT('hello',2);

-- LPAD()|RPAD():用字符串填充到指定长度
SELECT LPAD('abc',10,'?');
SELECT RPAD('abc',10,'!');

-- 去掉字符串两端的空格TRIM()|LTRIM()|RTRIM():

SELECT CONCAT('*',TRIM(' abc '),'*'),CONCAT('*',LTRIM(' abc '),'*'),CONCAT('*',RTRIM(' abc '),'*');

-- REPEAT():重复指定的次数
SELECT REPEAT('hello',3);

-- REPLACE():字符串

SELECT REPLACE('hello king','king','queen');

-- 截取字符串SUBSTRING
SELECT SUBSTRING('abcdef',1,3);

-- 比较字符串
SELECT STRCMP('a','b');
------------------------------------------------------------------------------------

-- 测试日期时间函数
-- 返回当前日期(同义词关系)
SELECT CURDATE(),CURRENT_DATE();
-- 返回当前时间(同义词关系)
SELECT CURTIME(),CURRENT_TIME();
-- 返回当前的日期时间
--NOW和CURRENT_TIMESTAMP没区别，表示的是SQL开始执行时的系统时间；
--SYSDATE表示执行此函数时的系统时间。
SELECT NOW(),CURRENT_TIMESTAMP(),SYSDATE();
-- 返回日期中的月份和月份的名称
SELECT MONTH('2017-02-19');
SELECT MONTH(CURDATE()),MONTHNAME(CURDATE());
-- 返回星期几
SELECT DAYNAME(NOW());
-- 返回一周内的第几天,0代表星期一
SELECT DAYOFWEEK(NOW());
SELECT WEEK(NOW());
SELECT YEAR(NOW()),MONTH(NOW()),DAY(NOW()),HOUR(NOW()),MINUTE(NOW()),SECOND(NOW());

-- DATEDIFF()计算两个日期相差的天数
SELECT DATEDIFF('2017-03-06','2017-03-02');
------------------------------------------------------------------------------------

-- 测试其它常用函数
SELECT VERSION(),CONNECTION_ID();

SELECT USER(),CURRENT_USER(),SYSTEM_USER(),SESSION_USER();

-- 得到上一步插入操作产生AUTO_INCREMENT的值
SELECT LAST_INSERT_ID();

SELECT MD5('king');
-- PASSWORD():密码加密算法
SELECT PASSWORD('root');